function salida() {
  alert();
}
